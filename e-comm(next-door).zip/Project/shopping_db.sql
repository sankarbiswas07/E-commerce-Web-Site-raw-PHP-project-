-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 25, 2017 at 02:21 AM
-- Server version: 5.7.19-0ubuntu0.17.04.1
-- PHP Version: 7.0.22-0ubuntu0.17.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) NOT NULL,
  `product_title` varchar(200) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `qty` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  `total_amt` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `product_title`, `product_image`, `qty`, `price`, `total_amt`) VALUES
(12, 11, '0', 3, 'fastrack NG3800', 'ng38003pp08-fastrack-original-imaehtffnwbhebdd.jpeg', 1, 2200, 2200),
(13, 5, '0', 3, 'Samsung On Max', 'samsung-on-max.jpeg', 1, 28000, 28000),
(31, 2, '0', 6, 'Nike sport Shoe', 'revelution_nike_sport_shoe.jpeg', 1, 3000, 3000),
(32, 11, '0', 6, 'fastrack NG3800', 'ng38003pp08-fastrack-original-imaehtffnwbhebdd.jpeg', 1, 2200, 2200),
(43, 12, '0', 9, 'wrangler smooth', '32-ms17den002-metronaut-original-imaeuqkxy4xfgsmy.jpeg', 5, 3200, 16000),
(47, 3, '0', 1, 'Blue dress', 'blue dress.jpeg', 3, 4000, 12000),
(50, 10, '0', 1, 'jokey T-brand', 'l-ml-mens-ss17-fs-rnck-dgrey-thumb-ring-maniac-original-imaesrk8jy4yvp7x.jpeg', 1, 1200, 1200);

-- --------------------------------------------------------

--
-- Table structure for table `mast_customer`
--

CREATE TABLE `mast_customer` (
  `id` int(11) NOT NULL,
  `cust_name` varchar(200) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `emailid` varchar(100) NOT NULL,
  `cust_password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mast_customer`
--

INSERT INTO `mast_customer` (`id`, `cust_name`, `address`, `city`, `state`, `country`, `emailid`, `cust_password`) VALUES
(1, 'sankar prasad biswas', 'shyamnagar', 'kolkata', 'west bengal', 'india', 'sankarbiswas07@gmail.com', 'nopass'),
(2, 'Mousumi Biswas', 'shyamnagar', 'kolkata', 'west bengal', 'india', 'sathi@gmail.com', 'nopass'),
(6, 'Pratim Ghosh', 'Saktigarh', 'Bongaon', 'WB', 'India', 'pratim60@gmail.com', '1234'),
(9, 'Santu Pal', 'Bali', 'Kolkata', 'WB', 'India', 'santu@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `mast_product`
--

CREATE TABLE `mast_product` (
  `id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` double NOT NULL,
  `image_file_name` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mast_product`
--

INSERT INTO `mast_product` (`id`, `product_name`, `description`, `price`, `image_file_name`, `category_id`) VALUES
(1, 'Red check shirt', 'red colour check shirt', 800, 'redshirt.jpeg', 7),
(2, 'Nike sport Shoe', 'model : revolution\r\ncolour: dark gray with orange\r\ntype  : sports shoe', 3000, 'revelution_nike_sport_shoe.jpeg', 8),
(3, 'Blue dress', 'brand : worhington\r\ncolour : blue\r\nsize : M', 4000, 'blue dress.jpeg', 9),
(4, 'Samsung galaxy on7', 'colour : grey\r\nsim :dual\r\n', 19000, 'samsung-galaxy-on7.jpeg', 10),
(5, 'Samsung On Max', 'colour : black', 28000, 'samsung-on-max.jpeg', 10),
(6, 'Bajaj go plane', 'power saver', 1500, 'bajaj-dx6-original-imaenypbyf3ajjdy.jpeg', 11),
(7, 'Samsung wave cook', 'colour : black\r\nsize : 3 ltr', 7000, 'samsung-ms23f301tak-tl-original-imadwr9mkk6gdsza.jpeg', 13),
(8, 'nikon-d3300-dslr', 'jhakass camera', 50000, 'nikon-d3300-dslr.jpeg', 12),
(9, 'LG wash', 'five star power saver', 9000, 'lg-fh0b8ndl22-original-imaefkptu8efam4v.jpeg', 14),
(10, 'jokey T-brand', 'colour : grey\r\ncotton\r\nfull sleeve', 1200, 'l-ml-mens-ss17-fs-rnck-dgrey-thumb-ring-maniac-original-imaesrk8jy4yvp7x.jpeg', 4),
(11, 'fastrack NG3800', 'colour: orange\r\n', 2200, 'ng38003pp08-fastrack-original-imaehtffnwbhebdd.jpeg', 5),
(12, 'wrangler smooth', 'colour : blue\r\nsize : 30', 3200, '32-ms17den002-metronaut-original-imaeuqkxy4xfgsmy.jpeg', 6);

-- --------------------------------------------------------

--
-- Table structure for table `mast_product_category`
--

CREATE TABLE `mast_product_category` (
  `id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mast_product_category`
--

INSERT INTO `mast_product_category` (`id`, `category_name`) VALUES
(4, 'T-shirt(Men)'),
(5, 'Watch-Men'),
(6, 'Jeans(Men)'),
(7, 'Shirt(Men)'),
(8, 'Shoes'),
(9, 'Dress(Women)'),
(10, 'Mobile'),
(11, 'Iorn'),
(12, 'Camera'),
(13, 'Micro Wave Ovens'),
(14, 'Washing Mechine');

-- --------------------------------------------------------

--
-- Table structure for table `mst_admin`
--

CREATE TABLE `mst_admin` (
  `id` int(11) NOT NULL,
  `login_user` varchar(10) NOT NULL,
  `login_pass` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_admin`
--

INSERT INTO `mst_admin` (`id`, `login_user`, `login_pass`) VALUES
(1, 'hero', 'hero');

-- --------------------------------------------------------

--
-- Table structure for table `trans_order`
--

CREATE TABLE `trans_order` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `cast_namee` varchar(20) NOT NULL,
  `order_date` varchar(15) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_price` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `order_value` int(11) NOT NULL,
  `payment_complete` char(1) NOT NULL,
  `order_id` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trans_order`
--

INSERT INTO `trans_order` (`id`, `customer_id`, `cast_namee`, `order_date`, `product_id`, `product_price`, `quantity`, `order_value`, `payment_complete`, `order_id`) VALUES
(32, 1, 'sankar prasad biswas', '05/09/2017', 10, 1200, 3, 3600, 'y', '05092017110903'),
(33, 1, 'sankar prasad biswas', '05/09/2017', 12, 3200, 2, 6400, 'y', '05092017110927'),
(34, 1, 'sankar prasad biswas', '05/09/2017', 1, 800, 2, 1600, 'y', '05092017110900'),
(35, 1, 'sankar prasad biswas', '05/09/2017', 10, 1200, 2, 2400, 'y', '05092017110942'),
(36, 1, 'sankar prasad biswas', '05/09/2017', 10, 1200, 10, 12000, 'y', '05092017110956'),
(37, 1, 'sankar prasad biswas', '06/09/2017', 10, 1200, 2, 2400, 'y', '06092017120956'),
(38, 1, 'sankar prasad biswas', '06/09/2017', 12, 3200, 7, 22400, 'y', '06092017010925'),
(39, 9, 'Santu Pal', '06/09/2017', 2, 3000, 2, 6000, 'y', '06092017010959'),
(40, 9, 'Santu Pal', '06/09/2017', 12, 3200, 5, 16000, 'y', '06092017010918'),
(41, 1, 'sankar prasad biswas', '06/09/2017', 11, 2200, 3, 6600, 'y', '06092017050937'),
(42, 1, 'sankar prasad biswas', '06/09/2017', 11, 2200, 2, 4400, 'y', '06092017050947'),
(43, 1, 'sankar prasad biswas', '07/09/2017', 11, 2200, 6, 13200, 'y', '07092017050903'),
(44, 1, 'sankar prasad biswas', '10/09/2017', 11, 2200, 6, 13200, 'y', '10092017090929'),
(45, 1, 'sankar prasad biswas', '10/09/2017', 3, 4000, 77, 308000, 'y', '10092017100906'),
(46, 1, 'sankar prasad biswas', '12/09/2017', 3, 4000, 10, 40000, 'y', '12092017110900'),
(47, 1, 'sankar prasad biswas', '17/09/2017', 3, 4000, 3, 12000, 'y', '17092017100957'),
(48, 1, 'sankar prasad biswas', '22/09/2017', 3, 4000, 3, 12000, 'y', '22092017100903'),
(49, 1, 'sankar prasad biswas', '22/09/2017', 10, 1200, 1, 1200, 'y', '22092017100955');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mast_customer`
--
ALTER TABLE `mast_customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mast_product`
--
ALTER TABLE `mast_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mast_product_category`
--
ALTER TABLE `mast_product_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mst_admin`
--
ALTER TABLE `mst_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trans_order`
--
ALTER TABLE `trans_order`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `mast_customer`
--
ALTER TABLE `mast_customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `mast_product`
--
ALTER TABLE `mast_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `mast_product_category`
--
ALTER TABLE `mast_product_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `mst_admin`
--
ALTER TABLE `mst_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `trans_order`
--
ALTER TABLE `trans_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
