<?php

require 'PHPMailer-master/PHPMailerAutoload.php';
        $mail = new PHPMailer();
        $name = $_POST["name"];
        $email = $_POST["email"];
       $comments=$_POST["comment"];
        //$name= "sankar";
      //  $email = "sankarbiswas07@gmail.com";
      //  $comments="hi";
        //echo $name.$email.$comments;
        //$id = $consign_no;
        //$status = ucwords($st);
        $message = '<html>
                      <body>
                          <div style="border-left: 15px solid #330066;border-right: 15px solid #330066">
                              <div>

                                 <center> <p>
                                  Hello admin, I am <b>' . $name . '</b>,<br/><br/>
                                      email address: ' . $email . '<br/><br/>
                                      want to tell you that <b> ' . $comments . '</b><br/>
                                      One more thing, I love NEXTDOOR service.<br/>

                                      Thank you.<br/><br/>
                              </div>
                          </div>
                      </body>
                      </html>';

        $mail->isSMTP();
        $mail->SMTPDebug = 0;
        $mail->Debugoutput = 'html';
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        $mail->SMTPSecure = 'tls';
        $mail->SMTPAuth = true;
        $mail->Username = "sankarbiswas07@gmail.com";
        $mail->Password = "nosmoking41";

        $mail->setFrom('sankarbiswas07@gmail.com', $name);
        $mail->addReplyTo($email, '');
        $mail->addAddress('sankarbiswas07@gmail.com', $name);
        $mail->Subject = 'FEEDBACK from NEXTDOOR : ';
       $mail->isHTML(true);
        $mail->Body = $message;
        $mail->AltBody = 'This is a plain-text message body';
//$mail->addAttachment('PHPMailer-master/examples/images/phpmailer_mini.png');
        if (!$mail->send()) {
            echo "Mailer Error: " . $mail->ErrorInfo;
        } else {
            echo "Thank you ". $name." , your feedback is important to us...";
        }


?>
