<?php
session_start();
  include 'connection.php';
//$connect = mysqli_connect("localhost","root","confirm","shopping_db");

$uid= $_SESSION['uid'];
$Old = $_POST['Op'];
$New = $_POST['Np'];

$sql1= mysqli_query($connect,"SELECT * FROM mast_customer WHERE `cust_password`= '$Old' ");
      if (mysqli_num_rows($sql1) == 0)     //if no row selected
          { echo "incorrect Old PassWord" ;}
      else{
              $sql = "UPDATE `mast_customer` SET `cust_password`= '$New' WHERE id='$uid'";
              if($run = mysqli_query($connect,$sql))
              {
                echo"Successfully Changed Password";
              }

              else
              {
                echo "Something went wrong";
              }
          }

 ?>
