<?php
//inser data from customer registration form
//$connect = mysqli_connect("localhost","root","confirm","shopping_db");
include 'connection.php';
$name = mysqli_real_escape_string($connect, $_POST["r_name"]);
$address = mysqli_real_escape_string($connect, $_POST["r_address"]);
$city = mysqli_real_escape_string($connect, $_POST["r_city"]);
$state = mysqli_real_escape_string($connect, $_POST["r_state"]);
$country = mysqli_real_escape_string($connect, $_POST["r_country"]);
$email = mysqli_real_escape_string($connect, $_POST["r_email"]);
$pass = mysqli_real_escape_string($connect, $_POST["r_password"]);

$email_val = filter_var($email, FILTER_SANITIZE_EMAIL);    // FILTER_SANITIZE_EMAIL is ussed to Remove all illegal characters from email

if(empty($_POST["r_name"] && $_POST["r_address"] && $_POST["r_city"] && $_POST["r_state"] && $_POST["r_country"] && $_POST["r_email"] && $_POST["r_password"] ))
    { echo "PLEASE FILLUP ALL THE INFORMATION..."; }
    elseif (!preg_match("/^[a-z A-Z'-]+$/", $name))
          { die ("Name shoud be [A-Z]&[a-z]");}
    elseif (filter_var($email_val, FILTER_VALIDATE_EMAIL))                // in build email validate methode in php
    {
      $query1 = mysqli_query($connect,"SELECT emailid FROM mast_customer WHERE emailid='$email'");     //checking for already exist username
      if (mysqli_num_rows($query1) == 0)     //if no row selected
      {
              $query="INSERT INTO mast_customer(cust_name, address, city, state, country, emailid, cust_password)
                       VALUES ('$name','$address','$city','$state','$country','$email','$pass')";
             if( mysqli_query($connect,$query))
                    echo "Thank You $name , You are Successfully Registerd";
              else
                    echo "OOPS!!! SEEMS LIKE PROBLEM.. TRY LETER !!!";
      }
      else
      {
                  echo "you are Registerd";
      }
}
else
{
    echo("$email is not a valid email address");
}

?>
