<?php
  include 'connection.php';

  $get_id = $_POST["id"];
  $cname = $_POST["cum"];
  $add = $_POST["ad"];
  $city = $_POST["ci"];
  $state = $_POST["st"];
  $country = $_POST["co"];
  $email = $_POST["em"];
  $pass = $_POST["pa"];

  $sql = "UPDATE mast_customer
          SET cust_name ='$cname', address='$add', city ='$city', state ='$state', country ='$country', emailid ='$email', cust_password ='$pass' WHERE id='$get_id'";
 if( mysqli_query($connect,$sql))
 {
   echo "Update Accepted!!!";
 }
 else {
   echo "Something Went Wrong";
 }
 ?>
