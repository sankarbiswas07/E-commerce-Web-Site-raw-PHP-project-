<?php
  include 'connection.php';

  $get_id = $_POST["id"];

  $qty = $_POST["qt"];
  $oval = $_POST["ov"];
  $prs = $_POST["pp"];
  $total = $qty*$prs;
  $sql = "UPDATE trans_order
          SET quantity ='$qty', order_value='$total'  WHERE id='$get_id'";
 if( mysqli_query($connect,$sql))
 {
   echo "Update Accepted!!!";

 }
 else {
   echo "Something Went Wrong";

 }
 ?>
