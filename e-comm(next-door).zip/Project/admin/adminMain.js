$(document).ready(function() {

  /* ajax script for contact us mail*/
  //mail validation function  FROM INDEX.PHP
          $("#acon_sub").click(function(e) {
              var name = $("#name").val();
              var email = $("#txtemail").val();
              var comm = $("#comment").val();
              //Check input Fields Should not be blanks.
              if (name == '' || email == '' || comm == '') {
              alert("please fill-up all the fields");
              e.preventDefault();
            }

               else {
                            //alert(email);
                               if (validateEmail(email))
                               {
                                     $.ajax({
                                             url    : 'email.php',
                                             type : 'POST',
                                             data   : {
                                                 name: name,
                                                 email: email,
                                                 comment: comm
                                             },
                                             success:function(response){
                                                $('#msg1').html(response);
                                             }

                                         });
                                     clearInput1();
                               }
                               else {
                                         alert('Invalid Email Address');
                                         e.preventDefault();
                               }
                  } });
                  // Function that validates email address through a regular expression.
                  function validateEmail(email) {
                          var filter = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
                          if (filter.test(email)) {
                          return true;
                          }
                          else {
                          return false;
                          }
                  }


                   function clearInput1(){      /*this jQuery function used to clear all fields after submission*/
                   $('#user_contact :input').each(function(){
                       $(this).val('');
                   });
                   $('#comment').val('');
                   }
                   $('#modalClose').click(function(){  /*this jQuery func is used to clead the #msg div on click of close button*/
                       $('#msg1').html("");
                   })

  /*CHANGE PASSWORD*/
  $("#aPass").click(function(e){
      e.preventDefault();
      var op = $("#Opass").val();
      var np = $("#Npass").val();
      var cp = $("#Cpass").val();
      //Check input Fields Should not be blanks.
      if (op == '' || np == '' || cp == '')
      {
          document.getElementById("msgk").innerHTML="please fill-up all the fields"
    }
       else if(np==cp)
                      {
                                  $.ajax({
                                  url: 'AdminChangePass.php',
                                  method: 'POST',
                                  data: {
                                  Op       : op,
                                  Np       : np
                                  },
                                  success:function(response)
                                  {
                                  $('#msgk').html(response);
                                  }
                                  });
                        }
          else { document.getElementById("msgk").innerHTML="password not matched!!!" }
                      clearInput();
                  });
      function clearInput(){      /*this jQuery function used to clear all fields after submission*/
      $('#ChangePassword1 :input').each(function(){
      $(this).val('');
      });

      }

      $('#modalClose').click(function(){  /*this jQuery func is used to clead the #msg div on click of close button*/
      $('#msgk').html("");
  })

/*admin login*/
  $("#a_submit").click(function(e){
                                 e.preventDefault();
                                 var email1 = $("#a_name").val();
                                 var pass1 = $("#a_pass").val();
if (email1 == '' || pass1 == '')
      {
          document.getElementById("amsg").innerHTML="please fill-up all the fields"
    }
       else {

                                 $.ajax
                                 ({
                                         url: 'adminlogin.php',
                                         method: 'POST',
                                         data: {
                                                  adminlogin:1,
                                                  adminEmail:email1,
                                                  adminPass:pass1
                                                },
                                        success:function(check)
                                        {
                                          if (check == "trueeeeeee")
                                          {
                                            window.location.href = "adminProfile.php";
                                          }
                                          else
                                           {
                                          window.location.href = "WarningAdmin.php";
                                           }
                                        }
                                });
}
                             });

/*order Management fetching table*/
 $("body").delegate(".option4","click",function() {

                $.ajax({
                        url:"adminOrderDisplay.php",
                        method:"POST",
                        success:function(data1)
                        {
                            $('#live_data').html(data1);
                        }
          })
  });
/*Customer Management fetching table*/
    $("body").delegate(".option3","click",function() {

                   $.ajax({
                           url:"adminCustomerDisplay.php",
                           method:"POST",
                           success:function(data1)
                           {
                               $('#live_data').html(data1);
                           }
             })
     });

/*Product Management fetching table*/
     $("body").delegate(".option2","click",function() {

                    $.ajax({
                            url:"adminProductDisplay.php",
                            method:"POST",
                            success:function(data1)
                            {
                                $('#live_data').html(data1);
                            }
              })
      });

  /*Category Management fetching table*/
       $("body").delegate(".option1","click",function() {

                      $.ajax({
                              url:"adminCategoryDisplay.php",
                              method:"POST",
                              success:function(data1)
                              {
                                  $('#live_data').html(data1);
                              }
                })
        });


});

/*Product management Adding product start here*/
$(document).on('click', '#btn_add', function(){
           var p_name = $('#p_name').text();
           var desc = $('#desc').text();
           var price = $('#price').text();
           var image = $('#image').text();
           var catId = $('#catId').text();

           if(p_name == '')       {alert("Enter Product Name");return false;}
           if(desc  == '')        {alert("Enter Description");return false;}
           if(price == '')        {alert("Enter Price");return false;}
           if(image  == '')       {alert("Enter Image Address");return false;}
           if(catId  == '')       {alert("Enter Category ID");return false;}

           $.ajax({
                url:"adminProductInsert.php",
                method:"POST",
                data:{
                          p_name:p_name,
                          desc:desc,
                          price:price,
                          image:image,
                          catId:catId
                       },
                success:function(ok)
                {
                     alert(ok);
                     fetch_product()

                }
           })

});
  function fetch_product(){
    $.ajax({
                url:"adminProductDisplay.php",
                method:"POST",
                success:function(data2)
                {
                    $('#live_data').html(data2);
                }
            })
  }
  /*Product management Adding product END here*/
/*Product management delete product start here*/
  $(document).on('click', '.btn_delete', function(){
             var id=$(this).data("id7");
             if(confirm("Are you sure you want to delete this?"))
             {
                  $.ajax({
                       url:"adminProductDelete.php",
                       method:"POST",
                       data:{id:id},
                       dataType:"text",
                       success:function(data){
                            $('#msg1').html(data);
                            //alert(data);
                            fetch_product();
                       }
                  });
             }
        });

/*Product manegment EDIT PRODUCT start here*/

$(document).on('click', '.btn_edit', function(){
           var id=$(this).data("id6");
            var p='#p'+id;
            var d='#d'+id;
            var pr='#pr'+id;
            var i='#i'+id;
            var c='#c'+id;

                $.ajax({
                     url:"adminProductUpdate.php",
                     method:"POST",
                     data:{
                            id:id,
                            p_name:$(p).text(),
                            desc:$(d).text(),
                            price:$(pr).text(),
                            image:$(i).text(),
                            catId:$(c).text()

                          },

                     success:function(data){
                          $('#msg1').html(data);
                          fetch_product();
                     }
                });
      });
/*_____________________________________________________________________________________________________________________________________*/
/*Category manegment starts here*/

/*category management Adding category start here*/
$(document).on('click', '#btn_C_add', function(){
           var c_name = $('#catName').text();

           if(c_name == '')       {alert("Enter Category Name");return false;}

           $.ajax({
                url:"adminCategoryInsert.php",
                method:"POST",
                data:{
                          c_name:c_name,
                       },
                success:function(ok)
                {
                     alert(ok);
                     fetch_category();

                }
           })

});
function fetch_category(){
  $.ajax({
              url:"adminCategoryDisplay.php",
              method:"POST",
              success:function(data2)
              {
                  $('#live_data').html(data2);
              }
          })
}
/*category manegment update category start here*/

$(document).on('click', '.btn_C_edit', function(){
           var id=$(this).data("id11");
            var catNm='#cn'+id;

                $.ajax({
                     url:"adminCategoryUpdate.php",
                     method:"POST",
                     data:{
                            id:id,
                            catNam:$(catNm).text()

                          },

                     success:function(data){
                          $('#msg1').html(data);
                          fetch_category();
                     }
                });
      });
      /*category management delete category start here*/
        $(document).on('click', '.btn_C_delete', function(){
                   var id=$(this).data("id12");
                   if(confirm("Are you sure you want to delete this?"))
                   {
                        $.ajax({
                             url:"adminCategoryDelete.php",
                             method:"POST",
                             data:{id:id},
                             dataType:"text",
                             success:function(data){
                                  $('#msg1').html(data);
                                  fetch_category();
                             }
                        });
                   }
              });
/*_____________________________________________________________________________________________________________________________________*/

/*category manegment update category start here*/

$(document).on('click', '.btn_CustEdit', function(){
           var id=$(this).data("id22");
            var cun='#cun'+id;
            var ad='#ad'+id;
            var ci='#ci'+id;
            var st='#st'+id;
            var co='#co'+id;
            var em='#em'+id;
            var pa='#pa'+id;

                $.ajax({
                     url:"adminCustomerUpdate.php",
                     method:"POST",
                     data:{
                            id:id,
                            cum:$(cun).text(),
                            ad:$(ad).text(),
                            ci:$(ci).text(),
                            st:$(st).text(),
                            co:$(co).text(),
                            em:$(em).text(),
                            pa:$(pa).text(),

                          },

                     success:function(data){
                          $('#msg1').html(data);
                          fetch_customer();
                     }
                });
      });
      function fetch_customer(){
        $.ajax({
                    url:"adminCustomerDisplay.php",
                    method:"POST",
                    success:function(data2)
                    {
                        $('#live_data').html(data2);
                    }
                })
      }

      /*Customer management delete customer start here*/
        $(document).on('click', '.btn_CustDelete', function(){
                   var id=$(this).data("id23");
                   if(confirm("Are you sure you want to delete this?"))
                   {
                        $.ajax({
                             url:"adminCustomerDelete.php",
                             method:"POST",
                             data:{id:id},
                             dataType:"text",
                             success:function(data){
                                  $('#msg1').html(data);
                                  fetch_customer();
                             }
                        });
                   }
              });

/*_____________________________________________________________________________________________________________________________________*/
/*EDIT ORDER FROM ADMIN PANEL STARTS HERE*/
$(document).on('click', '.btn_ordEdit', function(){

           var id=$(this).data("id34");

            var qt='#qt'+id;
            var ov='#ov'+id;
            var pp='#pp'+id;

                $.ajax({
                     url:"adminOrderUpdate.php",
                     method:"POST",
                     data:{
                            id:id,
                            qt:$(qt).text(),
                            ov:$(ov).text(),
                            pp:$(pp).text()
                          },

                     success:function(data){
                          $('#msg1').html(data);
                          fetch_order();
                     }
                });
      });
      function fetch_order(){
        $.ajax({
                    url:"adminOrderDisplay.php",
                    method:"POST",
                    success:function(data2)
                    {
                        $('#live_data').html(data2);
                    }
                })
      }
      /*_____________________________________________________________________________________________________________________________________*/
      /*Delete ORDER FROM ADMIN PANEL STARTS HERE*/

      /*Customer management delete customer start here*/
        $(document).on('click', '.btn_ordDelete', function(){
                   var id=$(this).data("id35");
                   if(confirm("Are you sure you want to delete this?"))
                   {
                        $.ajax({
                             url:"adminOrderDelete.php",
                             method:"POST",
                             data:{id:id},
                             dataType:"text",
                             success:function(data){
                                  $('#msg1').html(data);
                                  fetch_order();
                             }
                        });
                   }
              });







/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
