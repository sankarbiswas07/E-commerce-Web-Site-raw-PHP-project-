<?php
  include 'connection.php';

  $get_id = $_POST["id"];

  $pname = $_POST["p_name"];
  $desc = $_POST["desc"];
  $price = $_POST["price"];
  $image = $_POST["image"];
  $catid = $_POST["catId"];



  $sql = "UPDATE mast_product SET product_name ='$pname', description='$desc', price ='$price', image_file_name ='$image', category_id ='$catid' WHERE id='$get_id'";
 if( mysqli_query($connect,$sql))
 {
   echo "Product ID.$get_id. has been succesfully updated!!!";
 }
 else {
   echo "Something Went Wrong";
 }
 ?>
