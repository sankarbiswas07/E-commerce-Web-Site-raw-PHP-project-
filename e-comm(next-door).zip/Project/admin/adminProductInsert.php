

<?php
  include 'connection.php';

  $pname = mysqli_real_escape_string($connect, $_POST["p_name"]);
  $desc = mysqli_real_escape_string($connect, $_POST["desc"]);
  $price = mysqli_real_escape_string($connect, $_POST["price"]);
  $image = mysqli_real_escape_string($connect, $_POST["image"]);
  $catid = mysqli_real_escape_string($connect, $_POST["catId"]);

  $sql = "INSERT INTO mast_product (product_name, description, price, image_file_name, category_id)
          VALUES('$pname', '$desc','$price', '$image', '$catid')";
 if( mysqli_query($connect,$sql))
 {
   echo "Entry Accepted!!!";
 }
 else {
   echo "Something Went Wrong";
 }
 ?>
