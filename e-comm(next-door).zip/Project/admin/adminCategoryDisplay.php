<?php
 include 'connection.php' ;
 $output = '';
 $sql = "SELECT * FROM mast_product_category ORDER BY id DESC";

 $result = mysqli_query($connect, $sql);

 $output .= '<div class="alert alert-info" id="alert_message">
<strong><p id="msg1" style="color:green;padding-left:17vw float:left"></p></strong>
</div>';

 $output .= '
      <div class="table-responsive" style="height: 350px">
           <table id="user_data" class="table table-striped">

                    <tr>
                         <th width="40%">Id</th>
                         <th width="40%">Category Name</th>
                         <th width="20%">Action</th>
                    </tr>';

 if(mysqli_num_rows($result) > 0)
 {
   $output .= '
                  <tr>
                       <td></td>
                       <td id="catName" contenteditable></td>
                       <td><button type="button" name="add" id="btn_C_add"
                             class="btn btn-xs btn-warning">Add Category</button></td>
                 </tr>
             ';

            while($row =mysqli_fetch_array($result))
            {
                 $output .= '
                      <tr>
                          <td>'.$row["id"].'</td>
                         <td class="category_name" id="cn'.$row["id"].'" contenteditable>'.$row["category_name"].'</td>
                         <td>
                            <button type="button" name="update_btn" data-id11="'.$row["id"].'" class="btn btn-xs btn-success btn_C_edit">
                            <span class="glyphicon glyphicon-pencil"></span></button>

                            <button type="button" name="delete_btn" data-id12="'.$row["id"].'" class="btn btn-xs btn-danger btn_C_delete">
                            <span class="glyphicon glyphicon-trash"></span></button>
                         </td>
                      </tr>

                 ';
            }

 }
 else
 {
      $output .= '<tr>
                          <td colspan="4">Data not Found</td>
                     </tr>';
 }
 $output .= '</table>


      </div>';
 echo $output;
 ?>
