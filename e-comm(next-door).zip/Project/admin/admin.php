<?php
  session_start();
  if(isset($_SESSION["a_id"]))
  {
    header("location:adminProfile.php");
  }
?>
<html>
    <head>
    <meta charset="utf-8">
    <title>LOGIN PLEASE</title>
            <!--<link rel="stylesheet" href="css/bootstrap.min.css"/>
            <script src="js/jquery2.js"></script>
            <script src="js/bootstrap.min.js"></script> -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="admincustom.css">
        <script src="adminMain.js"></script>
    </head>

    <body>
              <div class="navbar navbar-inverse navbar-fixed-top">
                      <div class="container-fluid ">
                          <ul class="nav nav-pills navbar-left">
                              <li> <a href="admin.php" class="navbar-brand"><span class="glyphicon glyphicon-home"></span> N E X T - D O O R</a></li>
                      </div>
              </div>
<p><br  /></p>
<p><br  /></p>
<p><br  /></p>
<p><br  /></p>

<header id="footer">
  <p><div class="alert alert-info"><h3 class="text-center"> Admin Area <small>Account Login<div style="color:red;" id="amsg"></div></small></h3></div></p>
</header>


    <section id="main">
        <div class="container">
          <div class="row">
            <div class="col-md-4 col-md-offset-4">
              <form method="POST" id="login" action="adminlogin.php" class="well">
    			           <div class="form-group">
                          <label>Admin Id</label>
                          <input type="varchar" id="a_name"  class="form-control" placeholder="Enter User Id">
                      </div>
                      <div class="form-group">
                          <label>Password</label>
                          <input type="password" id="a_pass" name="pass" class="form-control" placeholder="Enter Password">
                      </div>
                          <button type="submit" id="a_submit" class="btn btn-default btn-block">Login</button>
                </form>
            </div>
          </div>
        </div>
    </section>

    <footer id="footer">
      <p><div class="alert alert-info"><h5 class="text-center"> Shopping means happiness &copy; 2017</h5></div></p>
    </footer>
  </body>
</html>
