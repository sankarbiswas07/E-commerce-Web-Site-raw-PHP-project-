<?php
 include 'connection.php' ;
 $output = '';
 $sql = "SELECT * FROM mast_customer ORDER BY id DESC";

 $result = mysqli_query($connect, $sql);

 $output .= '<div class="alert alert-info" id="alert_message">
<strong><p id="msg1" style="color:green;padding-left:17vw float:left"></p></strong>
</div>';

 $output .= '
      <div class="table-responsive" style="height: 350px">
           <table id="user_data" class="table table-striped">

                    <tr>
                         <th width="5%">Id</th>
                         <th width="15%">Customer Name</th>
                         <th width="15%">Address</th>
                         <th width="10%">City</th>
                         <th width="10%">State</th>
                         <th width="10%">Country</th>
                         <th width="15%">Email</th>
                         <th width="10%">Password</th>
                         <th width="10%">Action</th>
                    </tr>';

 if(mysqli_num_rows($result) > 0)
 {

            while($row =mysqli_fetch_array($result))
            {
                 $output .= '
                      <tr>
                          <td>'.$row["id"].'</td>
                         <td class="Customer_name"     id="cun'.$row["id"].'" contenteditable>'.$row["cust_name"].'</td>
                         <td class="Address"           id="ad'.$row["id"].'" contenteditable>'.$row["address"].'</td>
                         <td class="city"              id="ci'.$row["id"].'" contenteditable>'.$row["city"].'</td>
                         <td class="State"             id="st'.$row["id"].'" contenteditable>'.$row["state"].'</td>
                         <td class="Country"           id="co'.$row["id"].'" contenteditable>'.$row["country"].'</td>
                         <td class="emailId"           id="em'.$row["id"].'" contenteditable>'.$row["emailid"].'</td>
                         <td class="Password"          id="pa'.$row["id"].'" contenteditable>'.$row["cust_password"].'</td>
                         <td>
                            <button type="button" name="delete_btn" data-id22="'.$row["id"].'" class="btn btn-xs btn-success btn_CustEdit">
                            <span class="glyphicon glyphicon-pencil"></span></button>

                            <button type="button" name="update_btn" data-id23="'.$row["id"].'" class="btn btn-xs btn-danger btn_CustDelete">
                            <span class="glyphicon glyphicon-trash"></span></button>
                         </td>
                      </tr>

                 ';
            }

 }
 else
 {
      $output .= '<tr>
                          <td colspan="4">Data not Found</td>
                     </tr>';
 }
 $output .= '</table>


      </div>';
 echo $output;
 ?>
