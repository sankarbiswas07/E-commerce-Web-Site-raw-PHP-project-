
<?php
 include 'connection.php';
 $get_id = $_POST["id"];
 $sql = "DELETE FROM mast_product_category WHERE id = '$get_id'";
 if(mysqli_query($connect, $sql))
 {
      echo 'Category Deleted';
 }
 else {
   echo "Something went Wrong !!!";
 }
 ?>
