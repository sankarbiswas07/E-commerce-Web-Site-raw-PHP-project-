
<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
    <title>NEXT DOOR </title>
            <!--  <link rel="stylesheet" href="css/bootstrap.min.css"/>
          		<script src="js/jquery2.js"></script>
          		<script src="js/bootstrap.min.js"></script> -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>

  <div class="col-md-2">
      <div class="input-group">
        <input type='text' class='form-control qty' pid='$pro_id' id='qty-$pro_id' value='$qty'>
        <span class="input-group-btn">
        <a href='' update_id='$pro_id' class='btn btn-primary update'><span class='glyphicon glyphicon-pencil'></span></a>
        </span>

      </div><!-- /input-group -->
    </div><!-- /.col-md-2 -->

</body>
</html>
