<?php
  include 'connection.php';

  $get_id = $_POST["id"];

  $cat_Nam = $_POST["catNam"];
    //echo "$pname";


  $sql = "UPDATE mast_product_category SET category_name ='$cat_Nam' WHERE id='$get_id'";
 if( mysqli_query($connect,$sql))
 {
   echo "Category ID.$get_id. has been succesfully updated!!!";
 }
 else {
   echo "Something Went Wrong";
 }
 ?>
