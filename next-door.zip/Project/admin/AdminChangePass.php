<?php
session_start();
 include 'connection.php' ;

$aid= $_SESSION['a_id'];
$Old = $_POST['Op'];
$New = $_POST['Np'];
echo "$old";

$sql1= mysqli_query($connect,"SELECT * FROM mst_admin WHERE login_pass= '$Old' ");
      if (mysqli_num_rows($sql1) == 0)     //if no row selected
          { echo "incorrect Old PassWord" ;}
      else{
                  $sql = "UPDATE `mst_admin` SET login_pass= '$New' WHERE id='$aid'";
                  if($run = mysqli_query($connect,$sql))
                  {
                    echo"Successfully Changed Password";
                  }

                  else
                  {
                    echo "Something went wrong";
                  }
          }

 ?>
