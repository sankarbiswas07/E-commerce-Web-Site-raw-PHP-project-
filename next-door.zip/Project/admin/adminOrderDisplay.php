<?php
 include 'connection.php' ;
 $output = '';
 $sql = "SELECT * FROM trans_order ORDER BY id DESC";

 $result = mysqli_query($connect, $sql);

 $output .= '<div class="alert alert-info" id="alert_message">
<strong><p id="msg1" style="color:green;padding-left:17vw float:left"></p></strong>
</div>';

 $output .= '
      <div class="table-responsive" style="height: 350px">
           <table id="user_data" class="table table-striped">

                    <tr>
                         <th width="5%">Order No</th>
                         <th width="15%">Customer Name</th>
                         <th width="15%">Date</th>
                         <th width="10%">Product ID</th>
                         <th width="10%">Product Price</th>
                         <th width="10%">Quantity</th>
                         <th width="15%">Total Amount</th>
                         <th width="10%">Payment Status</th>
                         <th width="10%">Action</th>
                    </tr>';

 if(mysqli_num_rows($result) > 0)
 {

            while($row =mysqli_fetch_array($result))
            {
                 $output .= '
                      <tr>
                          <td>'.$row["id"].'</td>
                         <td class="Customer_name"     id="cun'.$row["id"].'">'.$row["cast_namee"].'</td>
                         <td class="order_date"           id="od'.$row["id"].'" >'.$row["order_date"].'</td>
                         <td class="product_id"              id="pi'.$row["id"].'">'.$row["product_id"].'</td>
                         <td class="product_price"             id="pp'.$row["id"].'">'.$row["product_price"].'</td>
                         <td class="quantity"           id="qt'.$row["id"].'" contenteditable>'.$row["quantity"].'</td>
                         <td class="order_value"           id="ov'.$row["id"].'">'.$row["order_value"].'</td>
                         <td class="payment_complete"          id="pc'.$row["id"].'">'.$row["payment_complete"].'</td>
                         <td>
                            <button type="button" name="delete_btn" data-id34="'.$row["id"].'" class="btn btn-xs btn-success btn_ordEdit">
                            <span class="glyphicon glyphicon-pencil"></span></button>

                            <button type="button" name="update_btn" data-id35="'.$row["id"].'" class="btn btn-xs btn-danger btn_ordDelete">
                            <span class="glyphicon glyphicon-trash"></span></button>
                         </td>
                      </tr>

                 ';
            }

 }
 else
 {
      $output .= '<tr>
                          <td colspan="4">Data not Found</td>
                     </tr>';
 }
 $output .= '</table>


      </div>';
 echo $output;
 ?>
