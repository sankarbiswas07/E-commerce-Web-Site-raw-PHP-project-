<?php
 include 'connection.php' ;
 $output = '';
 $sql = "SELECT * FROM mast_product ORDER BY id DESC";

 $result = mysqli_query($connect, $sql);

 $output .= '<div class="alert alert-info" id="alert_message">
<strong><p id="msg1" style="color:green;padding-left:17vw float:left"></p></strong>
</div>';

 $output .= '
      <div class="table-responsive" style="height: 350px">
           <table id="user_data" class="table table-striped">

                    <tr>
                         <th width="10%">Id</th>
                         <th width="20%">Product Name</th>
                         <th width="15%">Description</th>
                         <th width="10%">Price</th>
                         <th width="15%">Image</th>
                         <th width="15%">Category ID</th>
                         <th width="15%">Action</th>

                    </tr>';

 if(mysqli_num_rows($result) > 0)
 {
   $output .= '
                  <tr>
                       <td></td>
                       <td id="p_name" contenteditable></td>
                       <td id="desc" contenteditable></td>
                       <td id="price" contenteditable></td>
                       <td id="image" contenteditable></td>
                       <td id="catId" contenteditable></td>
                       <td><button type="button" name="add" id="btn_add"
                             class="btn btn-xs btn-warning">Add Product</button></td>
                 </tr>
             ';

            while($row =mysqli_fetch_array($result))
            {
                 $output .= '
                      <tr>
                          <td>'.$row["id"].'</td>
                         <td class="product_name" id="p'.$row["id"].'" contenteditable>'.$row["product_name"].'</td>
                         <td class="description" id="d'.$row["id"].'" contenteditable>'.$row["description"].'</td>
                         <td class="price" id="pr'.$row["id"].'" contenteditable>'.$row["price"].'</td>
                         <td class="image" id="i'.$row["id"].'" contenteditable>'.$row["image_file_name"].'</td>
                         <td class="category" id="c'.$row["id"].'" contenteditable>'.$row["category_id"].'</td>
                         <td>
                            <button type="button" name="update_btn" data-id6="'.$row["id"].'" class="btn btn-xs btn-success btn_edit" id="update">
                            <span class="glyphicon glyphicon-pencil"></span></button>

                            <button type="button" name="delete_btn" data-id7="'.$row["id"].'" class="btn btn-xs btn-danger btn_delete" >
                            <span class="glyphicon glyphicon-trash"></span></button>
                         </td>
                      </tr>

                 ';
            }

 }
 else
 {
      $output .= '<tr>
                          <td colspan="4">Data not Found</td>
                     </tr>';
 }
 $output .= '</table>


      </div>';
 echo $output;
 ?>
