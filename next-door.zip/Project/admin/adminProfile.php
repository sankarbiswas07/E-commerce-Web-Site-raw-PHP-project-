<?php
  session_start();
  if(!isset($_SESSION["a_id"]))
  {
    header("location:admin.php");
  }

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">

    <title>MasterControl</title>

  <!--  <link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script> -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="admincustom.css">
        <script src="adminMain.js"></script>
  </head>
  <body class="a_profile">

    <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="container-fluid">
                    <div class="navbar-header ">
                      <ul class="nav nav-pills navbar-left">
                          <li> <a href="#" class="navbar-brand"><span class="glyphicon glyphicon-home"></span> N E X T - D O O R</a></li>
                        </ul>
                    </div>

                          <ul class="nav navbar-nav navbar-right" >

                                  <li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><font color="#80ff00"><span class="glyphicon glyphicon-th-large"></span>Logout</font></a>
                                        <ul class="dropdown-menu">
                                          <li><a href="#" style="color:blue;" data-backdrop="static" data-keyboard="false" data-toggle="modal" data-target="#ChangePassword1">
                                            <span class="glyphicon glyphicon-cog"></span> Change Password</a>
                                          </li>
                                          <li class="divider"></li>
                                          <li><a href="adminLogout.php"style="color:red;"><span class="glyphicon glyphicon-off"></span> LogOut</a> </li>
                                        </ul>
                                  </li>

                          </ul>

            </div>
    </div>
<!--admin cagory gulo ekhane-->
<p><br/></p>
<p><br/></p>

<div class="container-fluid">
    <div class="row">
            <div class="col-md-2">
                  <div id="get_control" data-spy="affix">
        <!--here category are listed-->
                        <div class='nav nav-pills nav-stacked'>
                              <li class='active'><h4>Control Panel</h4></li>
                              <li><a href='#' class='option1'>Manage Category</a></li>
                              <li><a href='#' class='option2'>Manage Product</a></li>
                              <li><a href='#' class='option3'>Manage Customer</a></li>
                              <li><a href='#' class='option4'>Manage Order</a></li>
                        </div>
                    </div>

            </div>

      <div class=" col-md-10">
              <div class="panel panel-danger">
                <div class="panel-heading">
                     <h4><strong><?php echo "WELCOME BACK ".$_SESSION["a_name"]; ?></strong><small> Your Wizzard </small></h4>

                   </div>
                        <div class="panel-body">
                            <div id="live_data">
                              <!--table data will rendering here :) -->
                            </div>
                        </div>
                        <div class="panel-footer">
                            <div class="text-center">
                              <div class="SpaceWord">
<!--CONTACT US declaration : check bellow for connecting codes-->
<b>  <a href="#" data-backdrop="static" data-keyboard="false" data-toggle="modal" data-target="#mymodal0">
  <font color="#9966ff"> <span class="glyphicon glyphicon-send"></font></span><font color="#000066">ContactUs</a></font>
<!--END CONTACT US declaration : check bellow for connecting codes-->
                                  <a data-toggle="collapse" data-parent="#accordion" href="#collapse1"><font color="#9966ff"><span class="glyphicon glyphicon-user"></font></span><font color="#000066">AboutUs</a></font>  <br />
                                </b>
                               </div>

                              Shopping means happiness &copy; 2017
                            </div>
                                          <div id="collapse1" class="panel-collapse collapse">
                                          <div class="panel-body">

                                            <blockquote>
                                              <p>
                                                <b>NEXT DOOR</b> is a E-commarce web site where Catagory, Product list is rendered dynamically, added by ADMIN panel.
                                                We used Bootstrap 3.7.3 , js, Ajax, MySQL, HTML 5, CSS3 technologies to accomplish our Industrial Project under the
                                                giudence of Mr. SOMNATH BASAK (Asst. Proff. Brainware Group of institution-SDET,CSE) &
                                                 Mr. SUBHAJYOTI MAHATA(Asst. Proff. Brainware Group of institution-SDET,CSE)
                                                 & Mr. SRIMANTA DALUI(Project Manager, WEBGURU INFOSYSTEM).
                                              </p>
                                                <footer class="text-right">Developed By <cite title="Source Title"><i>(Sankar Prasad Biswas, Pratim Ghosh, Suman Das)</i></cite></footer>
                                            </blockquote>




                                          </div>
                                          </div>
                        </div>    <!--write for panel footer-->
    <!--write for panel footer-->

              </div>

      </div>
    </div>
</div>


<!--CONTACT US DIALOG START which has been decalred above in NAVBAR :) -->
    <div class="modal fade" id="mymodal0" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3> Contact Us</h3>
                    </div>
                <form class="form-horizontal" role="form" id="user_contact">
                    <div class="modal-body">
                        <div class="form-group">
                            <lable for="name" class="col-xs-2 control-label" >NAME</lable>
                            <div class="col-xs-10">
                            <input type="text" class="form-control" name="name"id="name"  placeholder="Please fill up your first name & last name" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <lable for="email" class="col-xs-2 control-label" >E-MAIL</lable>
                             <div class="col-xs-10">
                            <input type="text" class="form-control" name="txtemail" id="txtemail" placeholder="eg. jhonsmith@gmail.com" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <lable for="comment" class="col-xs-2 control-label" >MESSAGE</lable>
                             <div class="col-xs-10">
                                 <textarea class="form-control" name="comment" id="comment" rows="6" placeholder="Enter your message here" required></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" id="acon_sub"  class="btn btn-primary" >Send</button>

                        <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>

                    </div>
                </form>
                <p id="msg1" style="color:green;padding-left:17vw"></p>
            </div>
        </div>
    </div>
<!--contact us modal END-->

 <!--ChangePassword DIALOG START which has been decalred above in NAVBAR :) -->
        <div class="modal fade" id="ChangePassword1" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 style="color:red;">Change Password</h3>

                    </div>
                <form class="form-horizontal" role="form" id="user_pass" action="AdminChangePass.php" method="post">
                    <div class="modal-body">
                        <div class="form-group">
                            <lable for="name" class="col-xs-6 control-label" >Old Password</lable>
                            <div class="col-xs-6">
                            <input type="text" class="form-control" name="Opass" id="Opass" /required>
                            </div>
                        </div>
                        <div class="form-group">
                            <lable for="name" class="col-xs-6 control-label" >New Password</lable>
                            <div class="col-xs-6">
                            <input type="text" class="form-control" name="Npass" id="Npass" /required>
                            </div>
                        </div>
                        <div class="form-group">
                            <lable for="name" class="col-xs-6 control-label" >Confirm Password</lable>
                            <div class="col-xs-6">
                            <input type="text" class="form-control" name="Cpass" id="Cpass" /required>
                            </div>
                        </div>


                    <div class="modal-footer">


                        <button type="button" id="aPass" value="Submit" class="btn btn-primary">Change</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal" id="modalClose">Close</button>

                    </div>
                </form>
                <p id="msgk" style="color:red;padding-left:2vw"></p>

            </div>
        </div>
    </div>
<!--change password modal END-->








  </body>
</html>
