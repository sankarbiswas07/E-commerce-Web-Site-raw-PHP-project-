<?php
session_start();

unset($_SESSION["a_id"]);

unset($_SESSION["a_name"]);

header("location:admin.php");

?>
