

<?php
  include 'connection.php';

  $cname = mysqli_real_escape_string($connect, $_POST["c_name"]);

  $sql = "INSERT INTO mast_product_category(category_name)
          VALUES('$cname')";
 if( mysqli_query($connect,$sql))
 {
   echo "New Category Added...";
 }
 else {
   echo "Something Went Wrong";
 }
 ?>
