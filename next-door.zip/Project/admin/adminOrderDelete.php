
<?php
 include 'connection.php';
 $get_id = $_POST["id"];
 $sql = "DELETE FROM trans_order WHERE id = '$get_id'";
 if(mysqli_query($connect, $sql))
 {
      echo 'Customer Data Deleted';
 }
 else {
   echo "Something went Wrong !!!";
 }
 ?>
