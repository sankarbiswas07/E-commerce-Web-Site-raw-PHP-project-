
<?php
 include 'connection.php';
 $get_id = $_POST["id"];
 $sql = "DELETE FROM mast_product WHERE id = '$get_id'";
 if(mysqli_query($connect, $sql))
 {
      echo 'Data Deleted';
 }
 else {
   echo "Something went Wrong !!!";
 }
 ?>
