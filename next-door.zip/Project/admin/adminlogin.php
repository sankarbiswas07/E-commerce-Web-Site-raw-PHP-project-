<?php
include 'connection.php';
session_start();
if(isset($_POST["adminlogin"]))
{
    $email = mysqli_real_escape_string($connect,$_POST["adminEmail"]);
    $password = $_POST["adminPass"];
    $sql = "SELECT * FROM `mst_admin` WHERE login_user = '$email' AND login_pass= '$password' ";
    $run = mysqli_query($connect,$sql);
    $count = mysqli_num_rows($run);
    if($count == 1)
    {
        $row = mysqli_fetch_array($run);

          $_SESSION["a_id"] = $row["id"];
          $_SESSION["a_name"] = $row["login_user"];
          echo "trueeeeeee";

    }
}
?>
