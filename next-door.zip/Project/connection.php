<?php
$connect = mysqli_connect("localhost","root","confirm","shopping_db");
?>
