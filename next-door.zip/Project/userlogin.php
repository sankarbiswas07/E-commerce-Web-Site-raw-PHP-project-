<?php
include 'connection.php';
//$connect = mysqli_connect("localhost","root","confirm","shopping_db");

session_start();

if(isset($_POST["userlogin"]))
{
    $email = mysqli_real_escape_string($connect,$_POST["userEmail"]);
    $password = $_POST["userPass"];
    $sql = "SELECT * FROM `mast_customer` WHERE emailid = '$email' AND cust_password = '$password' ";
    $run = mysqli_query($connect,$sql);
    $count = mysqli_num_rows($run);
    if($count > 0)
    {
        $row = mysqli_fetch_array($run);

          $_SESSION["uid"] = $row["id"];
          $_SESSION["uname"] = $row["cust_name"];
          echo "trueeeeeee";

    }
	else
	{
    echo "incorrect username or password";
	}
}

?>
