<?php
session_start();
require("fpdf/fpdf.php");
if(!isset($_SESSION["uid"]))
  {
    header("location:index.php");
  }
  include 'connection.php';
//$connect=mysqli_connect("localhost","root","confirm","shopping_db");
$user_id=$_SESSION["uid"];
$c_name=$_SESSION["uname"];
$order=date("dmYhms");
$sql="select * from trans_order where order_id='$order'";
	$run_query=mysqli_query($connect,$sql);
	while($row=mysqli_fetch_array($run_query))
		{
			     $id=$row["id"];
                 $c_id = $row["customer_id"];
				 $order_dt = $row["order_date"];
                 $pro_id = $row["product_id"];
				 $pro_price = $row["product_price"];
				 $qty = $row["quantity"];
	$sql1="select * from cart where p_id='$pro_id'";
	$run_query1=mysqli_query($connect,$sql1);
	while($row1=mysqli_fetch_array($run_query1))
		{
                 $title= $row1["product_title"];
				 $price = $row1["price"];

$pdf=new FPDF();
$pdf->AddPage();

$pdf->SetFillColor(163,171,246);
$pdf->SetFont("Arial","",16);
$pdf->Cell(0,10,"Order Details",1,1,"C");
$pdf->Cell(0,10,"",0,1);

$pdf->Cell(30,10,"",0,0);
$pdf->Cell(60,10,"Order Id:",1,0,"","true");
$pdf->Cell(60,10,$id,1,1);

$pdf->Cell(30,10,"",0,0);
$pdf->Cell(60,10,"Customer Id:",1,0,"","true");
$pdf->Cell(60,10,$c_id,1,1);

$pdf->Cell(30,10,"",0,0);
$pdf->Cell(60,10,"Customer Name:",1,0,"","true");
$pdf->Cell(60,10,$c_name,1,1);

$pdf->Cell(30,10,"",0,0);
$pdf->Cell(60,10,"Product Id:",1,0,"","true");
$pdf->Cell(60,10,$pro_id,1,1);

$pdf->Cell(30,10,"",0,0);
$pdf->Cell(60,10,"Product Name:",1,0,"","true");
$pdf->Cell(60,10,$title,1,1);

$pdf->Cell(30,10,"",0,0);
$pdf->Cell(60,10,"Price:",1,0,"","true");
$pdf->Cell(60,10,$price,1,1);

$pdf->Cell(30,10,"",0,0);
$pdf->Cell(60,10,"Number of Items:",1,0,"","true");
$pdf->Cell(60,10,$qty,1,1);

$pdf->Cell(30,10,"",0,0);
$pdf->Cell(60,10,"Total Price:",1,0,"","true");
$pdf->Cell(60,10,$pro_price,1,1);

$pdf->Cell(30,10,"",0,0);
$pdf->Cell(60,10,"Payment Mode:",1,0,"","true");
$pdf->Cell(60,10,"Cash On Delivery",1,1);

$pdf->Cell(30,10,"",0,0);
$pdf->Cell(60,10,"Date of Order:",1,0,"","true");
$pdf->Cell(60,10,$order_dt,1,1);

$pdf->Cell(30,10,"",0,0);
$pdf->Cell(60,10,"Delivery Date:",1,0,"","true");
$pdf->Cell(60,10,"Next 7 Working Days",1,1);
//$pdf->output();
$fileName = 'Order_Slip@'.$c_name.'.pdf';
$pdf->output($fileName,'D');
		}
		}
?>
