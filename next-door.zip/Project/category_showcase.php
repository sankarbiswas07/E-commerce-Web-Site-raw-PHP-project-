<?php

session_start();
  include 'connection.php';
//$connect = mysqli_connect("localhost","root","confirm","shopping_db");
    if(isset($_POST["category"]))
    {
          $category_query = "SELECT * FROM mast_product_category";
                if( $run_query = mysqli_query($connect,$category_query) )

                   //copy from index page to print category first: just chenged all "" to ''
                   echo "<div class='nav nav-pills nav-stacked'>
                     <li class='active'><a href='#'><h4>Categories</h4></a></li>";


                       while($row = mysqli_fetch_array($run_query)) {
                         $cid = $row["id"];
                         $cnm = $row["category_name"];
                         echo "

                                  <li><a href='#' class='category1' cid='$cid'>$cnm</a></li>

                         ";
                       }
                       echo "</div>";
      }
  /*___________________________________________________________________________________________*/
        if(isset($_POST["getProduct"]))   //main page e 9 ta product show hobe
        {
                $product_query ="SELECT * FROM mast_product ORDER BY RAND() LIMIT 0,9";
                $run_query1 =mysqli_query($connect,$product_query);

                  while ($row = mysqli_fetch_array($run_query1)) {
                    $pro_name=$row['product_name'];
                    $pro_id=$row['id'];
                    $pro_dec=$row['description'];
                    $pro_rs=$row['price'];
                    $pro_img=$row['image_file_name'];
                    $pro_cat=$row['category_id'];
                    echo"
                    <div class='col-md-4'>
                            <div class='panel panel-info'>
                                    <div class='panel-heading'>$pro_name</div>
                                    <div class='panel-body'>
			<img src='IMGproduct/$pro_img' class='img-rounded' alt='no image' title='$pro_dec' width='150vw' height='150vh' />
                                    </div>
                                    <div class='panel-heading'> &#8377 $pro_rs
                                        <button pid='$pro_id' style='float:right;' id='product' class='btn btn-danger btn-xs'>AddToCart</button>

                                    </div>
                            </div>
                    </div>
                    ";
                }
            }
 /*<div id='picture'>
<a class='small' href='#nogo' title='small image'><img src='IMGproduct/$pro_img' title='$descript' height='250px' width='100px'/>
<img class='large' src='IMGproduct/$pro_img' title='large image' /></a>
</div> */
  /*___________________________________________________________________________________________*/

             if(isset($_POST["cat_id"]))
			 {
			 $cid = $_POST["cat_id"];
		     //cat-id te id eseche main.js e ajax er data part theke & kono catagory te click kore data show hobe
             $sql = "SELECT * FROM mast_product WHERE category_id = '$cid' ";
             $run = mysqli_query($connect,$sql);
             while ($row = mysqli_fetch_array($run))
             {
               $pro_name = $row['product_name'];
               $pro_id = $row['id'];
               $pro_dec = $row['description'];
               $pro_rs = $row['price'];
               $pro_img = $row['image_file_name'];
               $pro_cat = $row['category_id'];
               echo"
               <div class='col-md-4'>
                       <div class='panel panel-info'>
                               <div class='panel-heading'>$pro_name</div>
                               <div class='panel-body'>
							   <img src='IMGproduct/$pro_img' class='img-rounded' title='$pro_dec' alt='Cinque Terre' width='150vw' height='150vh' />
                               </div>
                               <div class='panel-heading'> &#8377 $pro_rs
                                   <button pid='$pro_id' style='float:right;' id='product' class='btn btn-danger btn-xs'>AddToCart</button>

                               </div>
                       </div>
               </div>
               ";
             }
			 }
			 /* <div id='picture'>
<a class='small' href='#nogo' title='small image'><img src='IMGproduct/$pro_img' title='$pro_dec' height='250px' width='100px'/>
<img class='large' src='IMGproduct/$pro_img' title='large image' /></a>
</div> <img src='IMGproduct/$pro_img' class='img-rounded' alt='Cinque Terre' width='150vw' height='150vh' />*/
  /*___________________________________________________________________________________________*/
       // Search bar  e search korar jonne.


             if(isset($_POST["search"]))
             {
               $keyword = $_POST["keyword"];        // main.js e ajax er data part theke
               $sql = "SELECT * FROM mast_product WHERE product_name LIKE '%$keyword%' OR description LIKE '%$keyword%' ";

               $run = mysqli_query($connect,$sql);
               while ($row = mysqli_fetch_array($run))
               {
                 $pro_name = $row['product_name'];
                 $pro_id = $row['id'];
                 $pro_dec = $row['description'];
                 $pro_rs = $row['price'];
                 $pro_img = $row['image_file_name'];
                 $pro_cat = $row['category_id'];                              //code for displaying 9 random product in mainpage
                 echo"
                 <div class='col-md-4'>
                         <div class='panel panel-info'>
                                 <div class='panel-heading'>$pro_name</div>
                                 <div class='panel-body'>
                                     <img src='IMGproduct/$pro_img' class='img-rounded' title='$pro_dec' alt='Cinque Terre' width='150vw' height='150vh' />
                                 </div>
                                 <div class='panel-heading'> &#8377 $pro_rs
                                     <button pid='$pro_id' style='float:right;' id='product' class='btn btn-danger btn-xs'>AddToCart</button>

                                 </div>
                         </div>
                 </div>
                 ";
               }
             }
  /*___________________________________________________________________________________________*/

if(isset($_POST['addToProduct']))         //add to cart button code. product datails will save inn cart table
{
	if(isset($_SESSION["uid"])){
	$p_id=$_POST["proId"];
	$user_id=$_SESSION["uid"];
	$sql="select * from cart where p_id='$p_id' AND user_id='$user_id'";
	$run_query=mysqli_query($connect,$sql);
	$count=mysqli_num_rows($run_query);
	if($count>0){
		echo "
		 <div class='alert alert-danger'>
					 <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
					 <b>Product is Already in Cart..<b>
					 </div>
		";
	}
	else{
		$sql="select * from mast_product where id='$p_id'";
		$run_query=mysqli_query($connect,$sql);
		$row=mysqli_fetch_array($run_query);
                 $pro_id = $row["id"];
                 $pro_name = $row["product_name"];
                 $pro_rs = $row["price"];
                 $pro_img = $row["image_file_name"];
				 $sql="INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `product_title`, `product_image`, `qty`, `price`, `total_amt`)
				 VALUES (NULL, '$pro_id', '0', '$user_id', '$pro_name', '$pro_img', '1', '$pro_rs', '$pro_rs')";

				 if(mysqli_query($connect,$sql)){
					 echo "
					 <div class='alert alert-success'>
					 <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
					 <b>Product is Added...!<b>
					 </div>
					 ";
				 }
	}
	}
	else
	{
		echo "
					<div class='alert alert-success'>
						<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
						<b>Sorry..!go and Sign Up First then you can add a product to your cart</b>
					</div>
				";
		}
}
/*_____________________________________________________________________________________________--*/
if(isset($_POST["get_cart_product"]) || isset($_POST["cart_checkout"]))
{
	$uid=$_SESSION["uid"];
	$sql="select * from cart where user_id='$uid'";
	$run_query=mysqli_query($connect,$sql);
	$count=mysqli_num_rows($run_query);
	if($count>0){
		$no=1;
		$total_amt=0;
		while($row=mysqli_fetch_array($run_query))
		{
                 $id=$row["id"];
				         $pro_id = $row["p_id"];
                 $pro_name = $row["product_title"];
                 $pro_rs = $row["price"];
                 $pro_img = $row["product_image"];
				 $qty=$row["qty"];
				 $total=$row["total_amt"];
				 $price_array=array($total);
				 $total_sum=array_sum($price_array);
				 $total_amt=$total_amt+$total_sum;
				 if(isset($_POST['get_cart_product'])){
					 echo "
					 <div class='row'>
					 <li class='divider'></li>
                     <div class='col-md-3'>$no</div>
                     <div class='col-md-3'><img src='IMGproduct/$pro_img' width='60px' height='50px'></div>
                     <div class='col-md-3'>$pro_name</div>
                     <div class='col-md-3'>&#8360;.$pro_rs.00</div>
                     </div>
					 ";
					 $no=$no + 1;
				 }
				 else{
					 echo "
	    <div class='row'>
		<hr class='divider'/>
		<div class='col-md-2'>
		<div class='btn-group'>

		<a href='#' remove_id='$pro_id' class='btn btn-danger remove' data-toggle='tooltip' title='Remove!'><span class='glyphicon glyphicon-trash'></span></a>
    <button buy_id='$pro_id' style='float:right;' id='buy' class='btn btn-success' data-toggle='tooltip' title='Buy Now!'>
    <span class='glyphicon glyphicon-shopping-cart'></span></button>

		</div>
		</div>
		<div class='col-md-2'><img src='IMGproduct/$pro_img' width='50px' height='60px'></div>
		<div class='col-md-2'>$pro_name</div>

    <div class='col-md-2'>
        <div class='input-group'>
                  <input type='text' class='form-control qty' pid='$pro_id' id='qty-$pro_id' value='$qty'>
                  <span class='input-group-btn'>
                  <a href='' update_id='$pro_id' class='btn btn-primary update' data-toggle='tooltip' title='Edit'><span class='glyphicon glyphicon-pencil'></span></a>
                  </span>

        </div>
      </div>

		<div class='col-md-2'><input type='text' class='form-control price' pid='$pro_id' id='price-$pro_id' value='$pro_rs' disabled></div>
		<div class='col-md-2'><input type='text' class='form-control total' pid='$pro_id' id='total-$pro_id'value='$total' disabled></div>

		</div>
		";
				 }

	    }
		if(isset($_POST["cart_checkout"])){
			echo"
      <p>
      <br  />
      </p>
			<div class='row'>

			<div class='col-md-4'><b>Payment Mode:</b><select disabled><option value='1'>Cash On Delivery</option><option value='2'>Online Payment</option></select></div>
            </div>
			";

		}
		        }
}
if(isset($_POST["cart_count"])){
	$uid=$_SESSION["uid"];
	$sql="select * from cart where user_id='$uid'";
	$run_query=mysqli_query($connect,$sql);
	echo mysqli_num_rows($run_query);
}
if(isset($_POST["removeFromCart"])){
	$pid=$_POST["removeId"];
	$uid=$_SESSION["uid"];
	$sql="delete from cart where user_id='$uid' AND p_id='$pid'";
	$run_query=mysqli_query($connect,$sql);
	if($run_query){
		echo "
		 <div class='alert alert-danger'>
					 <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
					 <b>Product is Removed from Cart..Continue Shopping..!<b>
					 </div>
		";
	}

}
if(isset($_POST["updateProduct"])){
	$pid=$_POST["updateId"];
	$uid=$_SESSION["uid"];
	$qty=$_POST["qty"];
	$price=$_POST["price"];
	$total=$_POST["total"];
	$sql="update cart set qty='$qty',price='$price',total_amt='$total' where user_id='$uid' AND p_id='$pid'";
	$run_query=mysqli_query($connect,$sql);
	if($run_query){
		echo "
		 <div class='alert alert-success'>
					 <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
					 <b>Product is Updated..Continue Shopping..!<b>
					 </div>
		";
	}

}
if(isset($_POST['buyProduct']))
{
	if(isset($_SESSION["uid"])){
	$uname=$_SESSION["uname"];
	$p_id=$_POST["proId"];
	$user_id=$_SESSION["uid"];
		$sql="select * from `cart` where p_id='$p_id' AND user_id='$user_id'";
		$run_query=mysqli_query($connect,$sql);
		$row=mysqli_fetch_array($run_query);
                 //$pro_name = $row["product_name"];
				 $total=$row["total_amt"];
				 $qty=$row["qty"];
         $rs=$row["price"];
				 $date=date("d/m/Y");
				 $order=date(dmYhms);
         $total1=($rs*$qty);
				 $sql="INSERT INTO `trans_order`
         (`id`, `customer_id`, `cast_namee`, `order_date`, `product_id`, `product_price`, `quantity`, `order_value`, `payment_complete`, `order_id`)
				 VALUES (NULL, '$user_id','$uname','$date', '$p_id','$rs','$qty', '$total1','y','$order')";

				 if(mysqli_query($connect,$sql))
				 {
					 $id=$_POST["id"];
					 echo "
					 <h1>Thank you </h1>
						<hr/>
						<p>Hello $uname,Your Order is
						successfully completed and your Order Id is $id<br/>
						you can continue your Shopping <br/></p>
					 ";
				 }
	}
	/*else
	{
		echo "
					<div class='alert alert-success'>
						<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
						<b>Sorry..!go and Sign Up First then you can add a product to your cart</b>
					</div>
				";
		}*/
}

?>
