<?php
  session_start();
  if(isset($_SESSION["uid"]))
  {
    header("location:userProfile.php");
  }
?>

<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
    <title>NEXT DOOR </title>
  <!--<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script> -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="custom.css">
        <script src="main.js"></script>

    </head>

    <body>

        <div class="navbar navbar-inverse navbar-fixed-top">

                <div class="container-fluid ">
                    <ul class="nav nav-pills navbar-left">
                        <li> <a href="index.php" class="navbar-brand"><span class="glyphicon glyphicon-home"></span> N E X T - D O O R</a></li>
                        <li style="width: 580px; left: 26px; top: 9px"><input type="text" placeholder="Search your Item" class="form-control" id="search"></li>
                        <li style="width: 70px; left: 27px; top: 9px"><button type="submit" name="search" class="btn btn-primary" id="search_btn" >Search</button></li>
                    </ul>
 <!--LogIN droup down strat-->
 <!--registration form  button initialize here-->
 <!--disabling modal  by clicking outside  : data-backdrop="static" data-keyboard="false"-->
                    <ul class="nav navbar-nav navbar-right">
                                  <!--CART drop down strat-->
                                  <li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-shopping-cart">
                                  </span>C A R T</a>
                                      <div class="dropdown-menu" style="width: 400px">
                                          <div class="panel panel-success">
                                              <div class="panel-heading">
                                                  <div class="row">
                                                      <div class="col-md-3">Sl.No</div>
                                                      <div class="col-md-3">Produce Image</div>
                                                      <div class="col-md-3">Product Name</div>
                                                      <div class="col-md-3"> Price in Rs.</div>
                                                  </div>
                                              </div>
                                          </div>
                                      </div>
                                  </li>
                                  <!--CART drop down end-->

                          <li><a href="#" data-backdrop="static" data-keyboard="false" data-toggle="modal" data-target="#myModalReg">
                            <span class="glyphicon glyphicon-user"></span> SignUp</a> </li>

                                      <li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span> SignIn</a>
                                                <ul class="dropdown-menu">
                                                    <div style="width:255px;">
                                                        <div class="panel">
                                                            <div class="panel-heading"><h3>L O G I N</h3></div>
                                                            <div class="panel-body">
                                                            <label for="email">E-MAIL</label>
                                                            <input type=email class="form-control" placeholder="Registered E-mail ID " id="email" required/>
                                                             <label for="password">PASSWORD</label>
                                                            <input type=password class="form-control" placeholder="Password here " id="password" required/>


                                                            </div>
                                                            <p><br/></p>
                                                             <div class="panel-footer" id="e_msg">
															                                 <p id="msgx" style="color:green;padding-left:2vw"></p>
                                                             <input type="submit" class="btn btn-success" style="float:right;" id="login" value="LogIn">
															                                </div>
                                                        </div>
                                                    </div>
                                                </ul>
            <!--LogIN droup down end--> </li>
                            </ul>
                        </div>
                    </div>
            </div>
  <!--catagory coding left side listed-->

        <p><br/></p>
        <p><br/></p>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-2">

                      <div id="get_category">
<!--here category are listed-->

                      </div>
                    </div>

                <!--main body for showcase-->
                <div class="col-md-8">
            				<div class="row">
            				<div class="col-md-12" id="product_msg">
            				</div>
				                </div>
                        <div class="panel panel-info">
                          <div class="panel-heading">Products</div>
                                  <div class="panel-body">
                                    <div id="get_product">

                                    </div>
                                          <!--<div class="col-md-4">
                                                  <div class="panel panel-info">
                                                          <div class="panel-heading"></div>
                                                          <div class="panel-body">
                                                              <img src="IMGproduct/bosch-drill.jpeg" class="img-rounded" alt="Cinque Terre" width="150" height="150" />
                                                          </div>
                                                          <div class="panel-heading"> Rs. 00.00 /-
                                                              <button style="float:right;" class="btn btn-danger btn-xs">AddToCart</button>
                                                          </div>
                                                  </div>
                                          </div> -->
                                  </div>
                                  <div class="panel-footer">
                                      <div class="text-center">
                                        <div class="SpaceWord">
    <!--CONTACT US declaration : check bellow for connecting codes-->
                                          <b>  <a href="#" data-backdrop="static" data-keyboard="false" data-toggle="modal" data-target="#myModal">
                                            <font color="#9966ff"> <span class="glyphicon glyphicon-send"></font></span><font color="#000066">ContactUs</a></font>
   <!--END CONTACT US declaration : check bellow for connecting codes-->
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse1"><font color="#9966ff"><span class="glyphicon glyphicon-user"></font></span><font color="#000066">AboutUs</a></font>  <br />
                                          </b>
                                         </div>

                                        Shopping means happiness &copy; 2017
                                      </div>
                                                    <div id="collapse1" class="panel-collapse collapse">
                                                    <div class="panel-body">

                                                      <blockquote>
                                                          <p>
                                                            <b>NEXT DOOR</b> is a E-commarce web site where Catagory, Product list is rendered dynamically, added by ADMIN panel.
                                                            We used Bootstrap 3.7.3 , js, Ajax, MySQL, HTML 5, CSS3 technologies to accomplish our Industrial Project under the
                                                            giudence of Mr. SOMNATH BASAK (Asst. Proff. Brainware Group of institution-SDET,CSE) &
                                                             Mr. SUBHAJYOTI MAHATA(Asst. Proff. Brainware Group of institution-SDET,CSE)
                                                             & Mr. SRIMANTA DALUI(Project Manager, WEBGURU INFOSYSTEM).
                                                          </p>
                                                          <footer class="text-right">Developed By <cite title="Source Title"><i>(Sankar Prasad Biswas, Pratim Ghosh, Suman Das)</i></cite></footer>
                                                      </blockquote>




                                                    </div>
                                                    </div>
                                  </div>    <!--write for panel footer-->

                        </div>

                </div>


            </div>


        </div>




<!--*************************************************************************************************************************-->
<!--*************************************************************************************************************************-->


<!--CONTACT US DIALOG START which has been decalred above in NAVBAR :) -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3> Contact Us</h3>
                    </div>
                <form class="form-horizontal" role="form" id="user_contact" >
                    <div class="modal-body">
                        <div class="form-group">
                            <lable for="name" class="col-xs-2 control-label" >NAME</lable>
                            <div class="col-xs-10">
                            <input type="text" class="form-control" name="name" id="name"  placeholder="Please fill up your first name & last name" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <lable for="email" class="col-xs-2 control-label" >E-MAIL</lable>
                             <div class="col-xs-10">
                            <input type="text" class="form-control" name="txtemail" id="txtemail" placeholder="eg. jhonsmith@gmail.com" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <lable for="comment" class="col-xs-2 control-label" >MESSAGE</lable>
                             <div class="col-xs-10">
                                 <textarea class="form-control" name="comment" id="comment" rows="6" placeholder="Enter your message here" required></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" id="con_sub" value="Submit" class="btn btn-primary">Send</button>

                        <button type="button" class="btn btn-danger" data-dismiss="modal" >Close</button>

                    </div>
                </form>
                <p id="msg1" style="color:green;padding-left:17vw"></p>
            </div>
        </div>
    </div>
<!--contact us modal END-->

 <!--Registration DIALOG START which has been decalred above in NAVBAR :) -->
        <div class="modal fade" id="myModalReg" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Sign Up</h3>

                    </div>
                <form class="form-horizontal" role="form" id="user_reg" action="signUp.php" method="post">
                    <div class="modal-body">
                        <div class="form-group">
                            <lable for="name" class="col-xs-2 control-label" >NAME</lable>
                            <div class="col-xs-10">
                            <input type="text" class="form-control" name="r_name" id="r_name"  placeholder="Please fill up your first name & last name" /required>
                            </div>
                        </div>
                        <div class="form-group">
                            <lable for="address" class="col-xs-2 control-label" >ADDRESS</lable>
                             <div class="col-xs-10">
                                 <textarea class="form-control" name="r_address"  id="r_address" rows="2" placeholder="Enter your message here" required></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <lable for="city" class="col-xs-2 control-label" >City</lable>
                             <div class="col-xs-2">
                                 <input type="text" class="form-control" name="r_city" id="r_city"  required>
                            </div>
                            <lable for="state" class="col-xs-2 control-label" >State</lable>
                            <div class="col-xs-2">
                                 <input type="text" class="form-control" name="r_state" id="r_state" required>
                            </div>
                            <lable for="country" class="col-xs-2 control-label" >Country</lable>
                            <div class="col-xs-2">

                                 <input type="text" class="form-control" name="r_country" id="r_country" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <lable for="email" class="col-xs-2 control-label" >E-MAIL</lable>
                            <div class="col-xs-4">
                            <input type="email" class="form-control" name="r_email" id="r_email" placeholder="eg.jhonsmith@gmail.com" required>
                            </div>
                            <lable for="password" class="col-xs-2 control-label" >Password</lable>
                            <div class="col-xs-4">
                            <input type="password" class="form-control" name="r_password" id="r_password" required>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <span id="result"></span>

                        <button type="button" id="reg_sub" value="Submit" class="btn btn-primary">Submit</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal" id="modalClose">Close</button>

                    </div>
                </form>
                <p id="msg" style="color:green;padding-left:2vw"></p>

            </div>
        </div>
    </div>
<!--Registration modal END-->


    </body>

</html>
