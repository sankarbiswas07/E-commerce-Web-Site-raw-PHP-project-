

$(document).ready(function() {

/*category feching from database and send a http request through a php*/
      $.ajax({
        url : "category_showcase.php",
        method : "POST",
        data:{
                category : 1
              },
        success : function(data){
                  $("#get_category").html(data);  //get_category is defined in index.php

        }
      });
// display the item in main panel body
      $.ajax({
        url : "category_showcase.php",
        method : "POST",
        data : {
                  getProduct : 1
                },
        success : function(data){
                  $("#get_product").html(data);  //get_category is defined in index.php
        }
      });
      /* ajax script for left side catagory click by using cid and class written in category.php*/
     $("body").delegate(".category1","click",function(event) {

                    event.preventDefault();
                    var cid = $(this).attr('cid');     /*var cid te akhon catagory is ache and comes from mcategory.php 17 no line.*/
                    $.ajax({
                      url : "category_showcase.php",
                      method : "POST",
                      data: {
                          cat_id: cid
                      },
                      success : function(data){
                                $("#get_product").html(data);  //get_category is defined in index.php
                      }
                    });
              })
 //category hover effect JQUERY
           $(".dropdown").hover(
                    function() {
                        $('.dropdwon-menu', this).stop( true, true ).fadeIn("slow");
                        $(this).toggleClass('open');
                        $('span', this).toggleClass("glyphicon-upload");
                    },
                    function() {
                        $('.dropdwon-menu', this).stop( true, true ).fadeOut("slow");
                        $(this).toggleClass('open');
                        $('span', this).toggleClass("glyphicon-upload");
                    });

/*ajax script used to inser data into mySql*/
        $("#reg_sub").click(function(e){
                                       e.preventDefault();
                                       $.ajax({
                                           url: 'signUp.php',
                                           method: 'POST',
                                           data: {
                                               r_name       : $('#r_name').val(),
                                               r_address    : $('#r_address').val(),
                                               r_city       : $('#r_city').val(),
                                               r_state      : $('#r_state').val(),
                                               r_country    : $('#r_country').val(),
                                               r_email      : $('#r_email').val(),
                                               r_password   : $('#r_password').val()
                                           },
                                          success:function(response)
                                          {
                                            $('#msg').html(response);
                                          }


                                      });
                                   clearInput();
                                   });

                                   function clearInput(){      /*this jQuery function used to clear all fields after submission*/
                                   $('#user_reg :input').each(function(){
                                       $(this).val('');
                                   });
                                   $('#r_address').val('');
                                   }

                                   $('#modalClose').click(function(){  /*this jQuery func is used to clead the #msg div on click of close button*/
                                       $('#msg').html("");
                                   })
/* ajax script for contact us mail*/
//mail validation function  FROM INDEX.PHP
        $("#con_sub").click(function(e) {
            var name = $("#name").val();
            var email = $("#txtemail").val();
            var comm = $("#comment").val();
            //Check input Fields Should not be blanks.
            if (name == '' || email == '' || comm == '') {
            alert("please fill-up all the fields");
            e.preventDefault();
          }

             else {
                          //alert(email);
                             if (validateEmail(email))
                             {
                                   $.ajax({
                                           url    : 'email.php',
                                           type : 'POST',
                                           data   : {
                                               name: name,
                                               email: email,
                                               comment: comm
                                           },
                                           success:function(response){
                                              $('#msg1').html(response);
                                           }

                                       });
                                   clearInput1();
                             }
                             else {
                                       alert('Invalid Email Address');
                                       e.preventDefault();
                             }
                } });
                // Function that validates email address through a regular expression.
                function validateEmail(email) {
                        var filter = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
                        if (filter.test(email)) {
                        return true;
                        }
                        else {
                        return false;
                        }
                }


                 function clearInput1(){      /*this jQuery function used to clear all fields after submission*/
                 $('#user_contact :input').each(function(){
                     $(this).val('');
                 });
                 $('#comment').val('');
                 }
                 $('#modalClose').click(function(){  /*this jQuery func is used to clead the #msg div on click of close button*/
                     $('#msg1').html("");
                 })

/* Search button Ajax method so that we can search
   in our SRS there is no keyword column in mast_product table,
   so i am implementing this feature with the product description & product name
   $("#search").val();  is the search bar's text id. written in index page
 */

     $("#search_btn").click(function() {
         var keyword = $("#search").val();
              if (keyword != "")
             {
                   $.ajax({
                       url    : 'category_showcase.php',
                       method : 'POST',
                       data   : {
                          search:1,
                          keyword:keyword
                       },
                       success:function(response){
                          $("#get_product").html(response);
                       }

                   });
              }
          });

/*LOGIN AJAX METHODE BUTTON ID = 'login'*/

$("#login").click(function(e){
                               e.preventDefault();
                               var email = $("#email").val();
                               var pass = $("#password").val();
                               $.ajax
                               ({
                                       url: 'userlogin.php',
                                       method: 'POST',
                                       data: {
                                                userlogin:1,
                                                userEmail:email,
                                                userPass:pass
                                              },
                                      success:function(check)
                                      {
                                        if (check == "trueeeeeee")
                                        {
                                          window.location.href = "userProfile.php";
                                        }
										else
										{
                                         $('#msgx').html(check);
                                        }

                                      }

                              });
                           })
/*change password*/
$("#cPass").click(function(e)
                    {
                         e.preventDefault();
                         e.preventDefault();
                         var op = $("#Opass").val();
                         var np = $("#Npass").val();
                         var cp = $("#Cpass").val();
                         //Check input Fields Should not be blanks.
                         if (op == '' || np == '' || cp == '')
                         {
                             document.getElementById("msgp").innerHTML="please fill-up all the fields"
                          }
                          else if(np==cp)
                           {
                               $.ajax({
                                                   url: 'changePass.php',
                                                   method: 'POST',
                                                   data: {
                                                                 Op       : op,
                                                                 Np       : np
                                                            },
                                                    success:function(response)
                                                  {
                                                    $('#msgp').html(response);
                                                  }
                                          });
                                        }
                              else{
                                document.getElementById("msgp").innerHTML="password not matched!!!"
                              }
                           clearInput();
                           });


                           function clearInput(){      /*this jQuery function used to clear all fields after submission*/
                           $('#ChangePassword :input').each(function(){
                               $(this).val('');
                           });

                           }

                           $('#modalClose').click(function(){  /*this jQuery func is used to clead the #msg div on click of close button*/
                               $('#msgp').html("");
                           })

/*********************************************************/
cart_count();
$("body").delegate("#product","click",function(event){

event.preventDefault();
var p_id=$(this).attr('pid');
$.ajax({
	url : "category_showcase.php",
	method : "POST",
	data:{addToProduct:1,proId:p_id},
	success : function(data){
    $("#product_msg").html(data);
	cart_count();
	}
});
})
cart_container();
function cart_container(){
	$.ajax({
	url : "category_showcase.php",
	method : "POST",
	data:{get_cart_product:1},
	success : function(data){
    $("#cart_product").html(data);
	}
})
};
cart_count();
function cart_count(){
	$.ajax({
	url : "category_showcase.php",
	method : "POST",
	data:{cart_count:1},
	success : function(data){
    $(".badge").html(data);
	}
})
};

$("#cart_container").click(function(event){
	event.preventDefault();
	$.ajax({
	url : "category_showcase.php",
	method : "POST",
	data:{get_cart_product:1},
	success : function(data){
    $("#cart_product").html(data);
	}
});

})
cart_checkout();
function cart_checkout(){
$.ajax({
	url : "category_showcase.php",
	method : "POST",
	data:{cart_checkout:1},
	success : function(data){
    $("#cart_checkout").html(data);
	}
});

}
$("body").delegate(".qty","keyup",function(){


    	var pid=$(this).attr("pid");
    	var qty=$("#qty-"+pid).val();
    	var price=$("#price-"+pid).val();
    	var total= qty * price;
    	$("#total-"+pid).val(total);

})
$("body").delegate(".remove","click",function(event){
	event.preventDefault();
	var pid=$(this).attr("remove_id");
	$.ajax({
	url : "category_showcase.php",
	method : "POST",
	data:{removeFromCart:1,removeId:pid},
	success : function(data){
    $("#cart_msg").html(data);
	cart_checkout();
	}
});
})
/*Quantity edit OPtion ___________________________________________________________________________________________*/
$("body").delegate(".update","click",function(event)
{
          event.preventDefault();
                            var pid=$(this).attr("update_id");
                            var qty=$("#qty-"+pid).val();
                            var price=$("#price-"+pid).val();
                            var total=$("#total-"+pid).val();
                            var intQTY=parseInt(qty);
                          //  alert(intQTY);
                            if(intQTY<=0)
                            {
                                alert("Sorry, Please select atleast One of this item");
                            }
                            else if (intQTY<1||intQTY>10)
                              {
                                              alert("Sorry, We have only 10 product of this item");
                              }
                            else
                            {
                                      	$.ajax({
                                      	url : "category_showcase.php",
                                      	method : "POST",
                                      	data:{updateProduct:1,updateId:pid,qty:qty,price:price,total:total},
                                      	success : function(data){
                                          $("#cart_msg").html(data);
                                      	cart_checkout();
                                      	}
                                      	})
                              }
})

$("body").delegate("#buy","click",function(event){

event.preventDefault();
var p_id=$(this).attr('buy_id');
$.ajax({
	url : "category_showcase.php",
	method : "POST",
	data:{buyProduct:1,proId:p_id},
	success : function(data){
  window.location.href="order_success.php";
	window.open("reply.php","_blank");
	}
});
})
  })
